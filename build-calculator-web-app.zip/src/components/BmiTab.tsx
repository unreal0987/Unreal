import React, { useState, useMemo } from 'react';
import { Scale, Activity } from 'lucide-react';
import { playSound } from '../utils/audio';
import { translations, Language } from '../utils/translations';

interface BmiTabProps {
  lang: Language;
  soundEnabled: boolean;
}

export const BmiTab: React.FC<BmiTabProps> = ({ lang, soundEnabled }) => {
  const t = translations[lang];

  // State
  const [weight, setWeight] = useState<number>(70); // 70 kg default
  const [height, setHeight] = useState<number>(170); // 170 cm default

  const bmiData = useMemo(() => {
    const w = weight;
    const h_m = height / 100; // convert cm to meters

    if (w <= 0 || h_m <= 0) {
      return {
        bmi: 0,
        category: '',
        colorClass: 'text-slate-400',
        barColor: 'bg-slate-800',
        pointerPercent: 0,
        advice: '',
        minIdealWeight: 0,
        maxIdealWeight: 0,
      };
    }

    const bmi = w / (h_m * h_m);
    
    // Category classification
    let category = '';
    let colorClass = '';
    let barColor = '';
    let advice = '';

    if (bmi < 18.5) {
      category = t.bmiUnderweight;
      colorClass = 'text-blue-400';
      barColor = 'bg-blue-400';
      advice = lang === 'en' 
        ? 'Eat energy-dense foods, build muscle, and consider eating more frequent meals!' 
        : 'ताकतवर खाना खाइए, थोड़ा प्रोटीन बढ़ाइए और दिन में बार-बार थोड़ा-थोड़ा खाइए!';
    } else if (bmi >= 18.5 && bmi < 25) {
      category = t.bmiNormal;
      colorClass = 'text-green-400';
      barColor = 'bg-green-400';
      advice = lang === 'en'
        ? 'Fantastic! Keep maintaining a balanced diet and regular physical activity.'
        : 'बहुत बढ़िया! अपनी डाइट को संतुलित रखें और रोज़ कसरत जारी रखें!';
    } else if (bmi >= 25 && bmi < 30) {
      category = t.bmiOverweight;
      colorClass = 'text-amber-400';
      barColor = 'bg-amber-400';
      advice = lang === 'en'
        ? 'Try incorporating more cardio, reducing sugary foods, and controlling portion sizes.'
        : 'कार्डियो एक्सरसाइज शुरू करें, मीठा थोड़ा कम करें और भोजन की मात्रा पर ध्यान दें!';
    } else {
      category = t.bmiObese;
      colorClass = 'text-red-400';
      barColor = 'bg-red-400';
      advice = lang === 'en'
        ? 'We recommend consulting with a doctor or a professional nutritionist to plan a sustainable routine.'
        : 'डॉक्टर या अच्छे डाइटिशियन से सलाह लेकर एक सही फिटनेस रूटीन बनाएं!';
    }

    // Gauge pointer: BMI scale from 15 to 40
    const minBmiScale = 15;
    const maxBmiScale = 40;
    const range = maxBmiScale - minBmiScale;
    const percent = Math.max(0, Math.min(100, ((bmi - minBmiScale) / range) * 100));

    // Ideal weight bounds
    const minIdealWeight = Math.round(18.5 * (h_m * h_m));
    const maxIdealWeight = Math.round(24.9 * (h_m * h_m));

    return {
      bmi: parseFloat(bmi.toFixed(1)),
      category,
      colorClass,
      barColor,
      pointerPercent: percent,
      advice,
      minIdealWeight,
      maxIdealWeight,
    };
  }, [weight, height, lang]);

  const handleSliderChange = (
    value: number,
    setter: React.Dispatch<React.SetStateAction<number>>
  ) => {
    if (soundEnabled) playSound('click');
    setter(value);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: React.Dispatch<React.SetStateAction<number>>
  ) => {
    let val = parseFloat(e.target.value);
    if (isNaN(val)) val = 0;
    setter(val);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-950/80 backdrop-blur-xl rounded-3xl border border-slate-800 p-6 shadow-2xl">
      <h2 className="text-slate-100 font-bold text-lg mb-1 flex items-center gap-2">
        <Activity className="w-5 h-5 text-indigo-400" />
        {t.tabBMI}
      </h2>
      <p className="text-slate-400 text-xs mb-6">{t.bmiDesc}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Side: Sliders */}
        <div className="space-y-6">
          {/* Weight */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-indigo-400" />
                {t.weight}
              </label>
              <input
                type="number"
                value={weight || ''}
                onChange={(e) => handleInputChange(e, setWeight)}
                className="w-20 px-2 py-1 bg-slate-900 border border-slate-800 text-slate-100 rounded-lg text-right font-mono font-bold text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <input
              type="range"
              min="20"
              max="180"
              step="1"
              value={weight}
              onChange={(e) => handleSliderChange(parseInt(e.target.value), setWeight)}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>20 kg</span>
              <span>180 kg</span>
            </div>
          </div>

          {/* Height */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-emerald-400" />
                {t.height}
              </label>
              <input
                type="number"
                value={height || ''}
                onChange={(e) => handleInputChange(e, setHeight)}
                className="w-20 px-2 py-1 bg-slate-900 border border-slate-800 text-slate-100 rounded-lg text-right font-mono font-bold text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <input
              type="range"
              min="90"
              max="220"
              step="1"
              value={height}
              onChange={(e) => handleSliderChange(parseInt(e.target.value), setHeight)}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>90 cm</span>
              <span>220 cm</span>
            </div>
          </div>
        </div>

        {/* Right Side: Visuals & Results */}
        <div className="flex flex-col justify-between bg-slate-900/40 border border-slate-850 rounded-2xl p-5 space-y-5">
          <div className="text-center space-y-1">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
              {t.yourBMI}
            </span>
            <div className="flex justify-center items-baseline gap-1">
              <span className={`text-4xl font-black font-mono tracking-tight ${bmiData.colorClass}`}>
                {bmiData.bmi}
              </span>
              <span className="text-xs text-slate-500 font-mono">kg/m²</span>
            </div>
            <p className={`text-sm font-semibold ${bmiData.colorClass} mt-1`}>
              {bmiData.category}
            </p>
          </div>

          {/* Health Gauge Slider */}
          <div className="space-y-1.5">
            <div className="relative w-full h-3 rounded-full bg-slate-800 overflow-hidden flex">
              <div className="w-[14%] bg-blue-400 h-full" title="Underweight (<18.5)"></div>
              <div className="w-[26%] bg-green-400 h-full" title="Normal (18.5-25)"></div>
              <div className="w-[20%] bg-amber-400 h-full" title="Overweight (25-30)"></div>
              <div className="w-[40%] bg-red-400 h-full" title="Obese (>30)"></div>
            </div>
            <div className="relative w-full h-4">
              {/* Sliding Pointer */}
              <div
                style={{ left: `${bmiData.pointerPercent}%` }}
                className="absolute top-0 transform -translate-x-1/2 flex flex-col items-center transition-all duration-500 ease-out"
              >
                <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[8px] border-b-indigo-400"></div>
                <span className="text-[9px] font-bold text-indigo-400 font-mono bg-indigo-500/10 border border-indigo-500/20 px-1 rounded mt-0.5 shadow-sm">
                  {bmiData.bmi}
                </span>
              </div>
            </div>
            <div className="flex justify-between text-[9px] text-slate-500 font-mono font-semibold px-0.5">
              <span>15 (Under)</span>
              <span>18.5</span>
              <span>25.0</span>
              <span>30.0</span>
              <span>40 (Obese)</span>
            </div>
          </div>

          {/* Health details & advice */}
          <div className="border-t border-slate-800 pt-3 space-y-2 text-xs">
            <p className="text-slate-300 font-medium leading-relaxed bg-indigo-500/5 border border-indigo-500/10 rounded-xl p-2.5">
              {bmiData.advice}
            </p>
            <div className="text-[11px] text-slate-400 flex flex-col gap-0.5 px-1">
              <span>{t.healthyRange}</span>
              <span className="text-emerald-400">
                {t.weightAdvice}{' '}
                <strong className="font-mono">
                  {bmiData.minIdealWeight} kg - {bmiData.maxIdealWeight} kg
                </strong>.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
