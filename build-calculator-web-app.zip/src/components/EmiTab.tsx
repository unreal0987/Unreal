import React, { useState, useMemo } from 'react';
import { HelpCircle, Calendar, DollarSign, Percent, TrendingUp } from 'lucide-react';
import { playSound } from '../utils/audio';
import { translations, Language } from '../utils/translations';

interface EmiTabProps {
  lang: Language;
  soundEnabled: boolean;
}

export const EmiTab: React.FC<EmiTabProps> = ({ lang, soundEnabled }) => {
  const t = translations[lang];

  // State inputs
  const [loanAmount, setLoanAmount] = useState<number>(1000000); // 10 Lakhs default
  const [interestRate, setInterestRate] = useState<number>(8.5); // 8.5% default
  const [tenure, setTenure] = useState<number>(15); // 15 Years default
  const [showSchedule, setShowSchedule] = useState<boolean>(false);

  // Math calculations
  const emiData = useMemo(() => {
    const P = loanAmount;
    const annualR = interestRate;
    const N_years = tenure;

    const R = annualR / 12 / 100; // Monthly interest rate
    const N = N_years * 12; // Total months

    if (P <= 0 || annualR <= 0 || N_years <= 0) {
      return {
        emi: 0,
        totalInterest: 0,
        totalPayment: 0,
        principalPercent: 100,
        interestPercent: 0,
        schedule: [],
      };
    }

    // Formula: EMI = [P x R x (1+R)^N]/[((1+R)^N)-1]
    const onePlusRToN = Math.pow(1 + R, N);
    const emi = (P * R * onePlusRToN) / (onePlusRToN - 1);

    const totalPayment = emi * N;
    const totalInterest = totalPayment - P;

    const principalPercent = (P / totalPayment) * 100;
    const interestPercent = (totalInterest / totalPayment) * 100;

    // Generate yearly amortization schedule
    const schedule = [];
    let balance = P;
    let accumulatedInterest = 0;
    let accumulatedPrincipal = 0;

    for (let year = 1; year <= N_years; year++) {
      let yearlyInterest = 0;
      let yearlyPrincipal = 0;

      // Calculate for 12 months in this year
      for (let m = 1; m <= 12; m++) {
        const interestForMonth = balance * R;
        const principalForMonth = emi - interestForMonth;
        
        yearlyInterest += interestForMonth;
        yearlyPrincipal += principalForMonth;
        balance = Math.max(0, balance - principalForMonth);
      }

      accumulatedInterest += yearlyInterest;
      accumulatedPrincipal += yearlyPrincipal;

      schedule.push({
        year,
        principalPaid: Math.round(yearlyPrincipal),
        interestPaid: Math.round(yearlyInterest),
        totalPaidThisYear: Math.round(yearlyPrincipal + yearlyInterest),
        balance: Math.round(balance),
      });
    }

    return {
      emi: Math.round(emi),
      totalInterest: Math.round(totalInterest),
      totalPayment: Math.round(totalPayment),
      principalPercent,
      interestPercent,
      schedule,
    };
  }, [loanAmount, interestRate, tenure]);

  const handleSliderChange = (
    value: number,
    setter: React.Dispatch<React.SetStateAction<number>>
  ) => {
    if (soundEnabled) playSound('click');
    setter(value);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: React.Dispatch<React.SetStateAction<number>>
  ) => {
    let val = parseFloat(e.target.value);
    if (isNaN(val)) val = 0;
    setter(val);
  };

  // SVG Donut Chart Constants
  const radius = 50;
  const circumference = 2 * Math.PI * radius; // ~314.16
  const principalStrokeDash = (emiData.principalPercent / 100) * circumference;
  const interestStrokeDash = (emiData.interestPercent / 100) * circumference;

  return (
    <div className="w-full max-w-4xl mx-auto bg-slate-950/80 backdrop-blur-xl rounded-3xl border border-slate-800 p-6 shadow-2xl">
      <h2 className="text-slate-100 font-bold text-lg mb-1 flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-indigo-400" />
        {t.tabEMI}
      </h2>
      <p className="text-slate-400 text-xs mb-6">{t.emiDesc}</p>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Sliders & Inputs */}
        <div className="lg:col-span-7 space-y-6">
          {/* Loan Amount */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-indigo-400" />
                {t.loanAmount}
              </label>
              <input
                type="number"
                value={loanAmount}
                onChange={(e) => handleInputChange(e, setLoanAmount)}
                className="w-32 px-2 py-1 bg-slate-900 border border-slate-800 text-slate-100 rounded-lg text-right font-mono font-bold text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <input
              type="range"
              min="10000"
              max="50000000"
              step="10000"
              value={loanAmount}
              onChange={(e) => handleSliderChange(parseFloat(e.target.value), setLoanAmount)}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>₹10,000</span>
              <span>₹5 Crore</span>
            </div>
          </div>

          {/* Interest Rate */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-1.5">
                <Percent className="w-4 h-4 text-amber-500" />
                {t.interestRate}
              </label>
              <input
                type="number"
                step="0.1"
                value={interestRate}
                onChange={(e) => handleInputChange(e, setInterestRate)}
                className="w-20 px-2 py-1 bg-slate-900 border border-slate-800 text-slate-100 rounded-lg text-right font-mono font-bold text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <input
              type="range"
              min="1"
              max="30"
              step="0.1"
              value={interestRate}
              onChange={(e) => handleSliderChange(parseFloat(e.target.value), setInterestRate)}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>1%</span>
              <span>30%</span>
            </div>
          </div>

          {/* Tenure */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-green-500" />
                {t.loanTenure}
              </label>
              <input
                type="number"
                value={tenure}
                onChange={(e) => handleInputChange(e, setTenure)}
                className="w-20 px-2 py-1 bg-slate-900 border border-slate-800 text-slate-100 rounded-lg text-right font-mono font-bold text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <input
              type="range"
              min="1"
              max="40"
              step="1"
              value={tenure}
              onChange={(e) => handleSliderChange(parseInt(e.target.value), setTenure)}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-green-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>1 Year</span>
              <span>40 Years</span>
            </div>
          </div>

          {/* EMI Summary Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-center items-center text-center shadow-inner">
            <span className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-1">
              {t.monthlyEMI}
            </span>
            <span className="text-3xl font-bold text-indigo-400 font-mono">
              ₹{emiData.emi.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Right Column: Donut Chart & Payout Details */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          <div className="flex flex-col items-center">
            {/* Donut Chart */}
            <div className="relative w-40 h-40">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                <circle
                  cx="60"
                  cy="60"
                  r={radius}
                  fill="transparent"
                  stroke="#1e293b"
                  strokeWidth="12"
                />
                {/* Principal Portion (indigo) */}
                <circle
                  cx="60"
                  cy="60"
                  r={radius}
                  fill="transparent"
                  stroke="#6366f1"
                  strokeWidth="12"
                  strokeDasharray={`${principalStrokeDash} ${circumference}`}
                  strokeDashoffset="0"
                  strokeLinecap="round"
                  className="transition-all duration-500 ease-out"
                />
                {/* Interest Portion (amber) */}
                {emiData.interestPercent > 0 && (
                  <circle
                    cx="60"
                    cy="60"
                    r={radius}
                    fill="transparent"
                    stroke="#f59e0b"
                    strokeWidth="12"
                    strokeDasharray={`${interestStrokeDash} ${circumference}`}
                    strokeDashoffset={-principalStrokeDash}
                    strokeLinecap="round"
                    className="transition-all duration-500 ease-out"
                  />
                )}
              </svg>
              <div className="absolute inset-0 flex flex-col justify-center items-center text-center">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Total Payout</span>
                <span className="text-sm font-bold text-slate-200 font-mono">
                  ₹{Math.round(emiData.totalPayment / 100000) / 10}L
                </span>
              </div>
            </div>

            {/* Legend */}
            <div className="flex gap-4 mt-3 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
                <span className="text-slate-300 font-medium">{t.principalLabel} ({Math.round(emiData.principalPercent)}%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                <span className="text-slate-300 font-medium">{t.interestLabel} ({Math.round(emiData.interestPercent)}%)</span>
              </div>
            </div>
          </div>

          {/* Numerical breakdown details */}
          <div className="space-y-3 bg-slate-900/40 border border-slate-850 rounded-2xl p-4">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">{t.principalAmount}</span>
              <span className="font-semibold text-slate-200 font-mono">
                ₹{loanAmount.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">{t.totalInterest}</span>
              <span className="font-semibold text-amber-400 font-mono">
                ₹{emiData.totalInterest.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="border-t border-slate-800 my-1"></div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-slate-300 font-medium">{t.totalPayment}</span>
              <span className="font-bold text-slate-100 font-mono">
                ₹{emiData.totalPayment.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Amortization Accordion */}
      <div className="mt-8 border-t border-slate-800 pt-6">
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              if (soundEnabled) playSound('click');
              setShowSchedule(!showSchedule);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-500/10 hover:bg-indigo-500/15 border border-indigo-500/20 text-indigo-400 rounded-xl text-sm font-semibold transition-all active:scale-95"
          >
            {showSchedule ? 'Hide Schedule' : 'Show Yearly Schedule'}
          </button>
          <div className="flex items-center gap-1 text-[11px] text-slate-500">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>{t.emiTips}</span>
          </div>
        </div>

        {showSchedule && (
          <div className="mt-4 overflow-x-auto rounded-2xl border border-slate-850 bg-slate-900/30 max-h-[300px] custom-scrollbar">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/80 text-xs font-semibold text-slate-400 font-mono uppercase tracking-wider">
                  <th className="p-3">Year</th>
                  <th className="p-3 text-right">Principal Paid</th>
                  <th className="p-3 text-right">Interest Paid</th>
                  <th className="p-3 text-right">Total Annual Payment</th>
                  <th className="p-3 text-right">Outstanding Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-xs text-slate-300">
                {emiData.schedule.map((row) => (
                  <tr key={row.year} className="hover:bg-slate-900/30 transition-colors">
                    <td className="p-3 font-semibold text-indigo-400">Year {row.year}</td>
                    <td className="p-3 text-right">₹{row.principalPaid.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-right text-amber-500/90">₹{row.interestPaid.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-right">₹{row.totalPaidThisYear.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-right text-slate-400 font-bold">₹{row.balance.toLocaleString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
