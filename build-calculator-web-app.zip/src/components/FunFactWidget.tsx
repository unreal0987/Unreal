import React, { useState, useEffect } from 'react';
import { Sparkles, RefreshCw } from 'lucide-react';
import { translations, Language } from '../utils/translations';
import { playSound } from '../utils/audio';

interface FunFactWidgetProps {
  lang: Language;
  soundEnabled: boolean;
}

export const FunFactWidget: React.FC<FunFactWidgetProps> = ({ lang, soundEnabled }) => {
  const t = translations[lang];
  const [index, setIndex] = useState(0);

  useEffect(() => {
    // Pick a random index when language changes or on load
    setIndex(Math.floor(Math.random() * t.funFacts.length));
  }, [lang]);

  const handleNextFact = () => {
    if (soundEnabled) playSound('click');
    let nextIndex = index;
    // Make sure we get a new index
    while (nextIndex === index && t.funFacts.length > 1) {
      nextIndex = Math.floor(Math.random() * t.funFacts.length);
    }
    setIndex(nextIndex);
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-indigo-950/40 to-slate-900/40 backdrop-blur-md rounded-2xl border border-indigo-500/20 p-4 shadow-md">
      <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>
      <div className="flex items-start justify-between gap-4">
        <div className="flex gap-3">
          <div className="p-2 bg-indigo-500/15 text-indigo-400 rounded-xl shrink-0 mt-0.5">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h4 className="font-semibold text-indigo-300 text-sm mb-1 uppercase tracking-wider">
              {t.funFactTitle}
            </h4>
            <p className="text-slate-300 text-sm leading-relaxed italic">
              "{t.funFacts[index]}"
            </p>
          </div>
        </div>
        <button
          onClick={handleNextFact}
          className="text-slate-400 hover:text-indigo-400 p-1.5 rounded-lg hover:bg-indigo-950/30 transition-all shrink-0 self-center"
          title="New Fact"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
