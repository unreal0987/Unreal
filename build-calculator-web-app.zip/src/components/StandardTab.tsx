import React, { useState, useEffect, useRef } from 'react';
import { Delete, HelpCircle } from 'lucide-react';
import { playSound } from '../utils/audio';
import { evaluateExpression } from '../utils/mathParser';
import { translations, Language } from '../utils/translations';
import { HistoryItem } from './HistorySidebar';

interface StandardTabProps {
  lang: Language;
  soundEnabled: boolean;
  onAddHistory: (expression: string, result: string, type: 'standard' | 'scientific') => void;
  activeHistoryItem: HistoryItem | null;
}

export const StandardTab: React.FC<StandardTabProps> = ({
  lang,
  soundEnabled,
  onAddHistory,
  activeHistoryItem,
}) => {
  const t = translations[lang];
  const [expression, setExpression] = useState<string>('');
  const [result, setResult] = useState<string>('0');
  const [memory, setMemory] = useState<number>(0);
  const [isCalculated, setIsCalculated] = useState<boolean>(false);
  const displayEndRef = useRef<HTMLDivElement>(null);

  // If a history item is selected, load it
  useEffect(() => {
    if (activeHistoryItem && activeHistoryItem.type === 'standard') {
      setExpression(activeHistoryItem.expression);
      setResult(activeHistoryItem.result);
      setIsCalculated(true);
    }
  }, [activeHistoryItem]);

  // Scroll display to the right when expression changes
  useEffect(() => {
    if (displayEndRef.current) {
      displayEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [expression]);

  // Handle keyboard inputs
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if focus is on input fields (like in other tabs, though standard is visible, just to be safe)
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }

      const key = e.key;
      if (/[0-9]/.test(key)) {
        handleKeyPress(key);
      } else if (key === '.') {
        handleKeyPress('.');
      } else if (key === '+') {
        handleKeyPress('+');
      } else if (key === '-') {
        handleKeyPress('-');
      } else if (key === '*') {
        handleKeyPress('×');
      } else if (key === '/') {
        handleKeyPress('÷');
      } else if (key === '(') {
        handleKeyPress('(');
      } else if (key === ')') {
        handleKeyPress(')');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleCalculate();
      } else if (key === 'Backspace') {
        handleBackspace();
      } else if (key === 'Escape') {
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [expression, isCalculated]);

  const handleKeyPress = (char: string) => {
    if (soundEnabled) playSound('click');
    
    if (isCalculated) {
      // If we just calculated, typing a number starts a new expression,
      // but typing an operator appends to the previous result.
      if (['+', '-', '×', '÷', '%', '^'].includes(char)) {
        setExpression(result + ' ' + char + ' ');
      } else {
        setExpression(char);
      }
      setIsCalculated(false);
    } else {
      // Add spaces around operators for nice formatting
      if (['+', '-', '×', '÷'].includes(char)) {
        setExpression((prev) => prev + ' ' + char + ' ');
      } else {
        setExpression((prev) => prev + char);
      }
    }
  };

  const handleClear = () => {
    if (soundEnabled) playSound('clear');
    setExpression('');
    setResult('0');
    setIsCalculated(false);
  };

  const handleBackspace = () => {
    if (soundEnabled) playSound('click');
    if (isCalculated) {
      setExpression('');
      setIsCalculated(false);
      return;
    }

    setExpression((prev) => {
      // If ends with a space (operator), delete the operator and its surrounding spaces
      if (prev.endsWith(' ')) {
        return prev.slice(0, -3);
      }
      return prev.slice(0, -1);
    });
  };

  const handleCalculate = () => {
    if (!expression) return;
    try {
      const computed = evaluateExpression(expression, 'deg');
      // Format result to prevent floating point issues (e.g. 0.1 + 0.2)
      // Check if it has decimals, format to 8 decimal places max, and strip trailing zeros
      let formattedResult = computed.toString();
      if (computed % 1 !== 0) {
        formattedResult = Number(computed.toFixed(10)).toString();
      }
      
      if (soundEnabled) playSound('success');
      setResult(formattedResult);
      onAddHistory(expression, formattedResult, 'standard');
      setIsCalculated(true);
    } catch (err) {
      if (soundEnabled) playSound('error');
      setResult('Error');
      setIsCalculated(true);
    }
  };

  const handleToggleSign = () => {
    if (soundEnabled) playSound('click');
    if (isCalculated) {
      const val = parseFloat(result);
      setResult((-val).toString());
      setExpression((-val).toString());
      setIsCalculated(false);
      return;
    }

    // Try to negate the last number in the expression
    // For simplicity, we can just wrap the expression in negative sign or toggle it
    if (expression.startsWith('-(') && expression.endsWith(')')) {
      setExpression(expression.slice(2, -1));
    } else {
      setExpression(`-(${expression})`);
    }
  };

  // Memory Functions
  const handleMemory = (op: 'MC' | 'MR' | 'M+' | 'M-' | 'MS') => {
    if (soundEnabled) playSound('click');
    const currentVal = parseFloat(result) || 0;

    switch (op) {
      case 'MC':
        setMemory(0);
        break;
      case 'MR':
        setExpression((prev) => prev + memory.toString());
        setIsCalculated(false);
        break;
      case 'M+':
        setMemory((prev) => prev + currentVal);
        break;
      case 'M-':
        setMemory((prev) => prev - currentVal);
        break;
      case 'MS':
        setMemory(currentVal);
        break;
    }
  };

  // Quick action buttons
  const handleQuickAction = (action: 'sqrt' | 'sqr' | 'percent') => {
    if (soundEnabled) playSound('click');
    
    if (isCalculated) {
      if (action === 'sqrt') {
        setExpression(`√(${result})`);
      } else if (action === 'sqr') {
        setExpression(`(${result})^2`);
      } else if (action === 'percent') {
        setExpression(`(${result})%`);
      }
      setIsCalculated(false);
      return;
    }

    if (action === 'sqrt') {
      setExpression((prev) => prev + '√(');
    } else if (action === 'sqr') {
      setExpression((prev) => (prev ? `(${prev})^2` : ''));
    } else if (action === 'percent') {
      setExpression((prev) => (prev ? `${prev}%` : ''));
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-slate-950/80 backdrop-blur-xl rounded-3xl border border-slate-800 p-5 shadow-2xl">
      <div className="text-slate-400 text-xs mb-3 flex items-center justify-between font-medium">
        <span>{t.standardDesc}</span>
        {memory !== 0 && (
          <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-400 rounded-full text-[10px] uppercase font-bold tracking-wider">
            Memory: {memory}
          </span>
        )}
      </div>

      {/* Screen Display */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800/80 mb-4 shadow-inner text-right flex flex-col justify-between min-h-[100px] overflow-hidden">
        <div className="text-slate-500 text-sm font-mono overflow-x-auto whitespace-nowrap pb-1 scrollbar-none flex justify-end">
          <div className="flex">
            {expression || '0'}
            <div ref={displayEndRef} />
          </div>
        </div>
        <div className="text-slate-100 text-3xl font-bold font-mono tracking-tight select-all break-all overflow-x-auto max-h-[80px] custom-scrollbar">
          {result}
        </div>
      </div>

      {/* Memory Pad */}
      <div className="grid grid-cols-5 gap-2 mb-3">
        {['MC', 'MR', 'M+', 'M-', 'MS'].map((op) => (
          <button
            key={op}
            onClick={() => handleMemory(op as any)}
            className="py-2 text-xs font-bold text-slate-400 hover:text-indigo-400 bg-slate-900/40 hover:bg-slate-800/50 rounded-xl transition-all active:scale-95 border border-slate-800/40"
          >
            {op}
          </button>
        ))}
      </div>

      {/* Main Buttons */}
      <div className="grid grid-cols-4 gap-2.5">
        {/* Row 1 */}
        <button
          onClick={handleClear}
          className="py-3.5 text-lg font-bold text-red-400 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-2xl transition-all active:scale-95"
        >
          C
        </button>
        <button
          onClick={() => handleKeyPress('(')}
          className="py-3.5 text-lg font-bold text-slate-300 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/50 rounded-2xl transition-all active:scale-95"
        >
          (
        </button>
        <button
          onClick={() => handleKeyPress(')')}
          className="py-3.5 text-lg font-bold text-slate-300 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/50 rounded-2xl transition-all active:scale-95"
        >
          )
        </button>
        <button
          onClick={handleBackspace}
          className="py-3.5 text-lg font-bold text-slate-400 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/50 rounded-2xl transition-all active:scale-95 flex items-center justify-center"
        >
          <Delete className="w-5 h-5" />
        </button>

        {/* Row 2 */}
        <button
          onClick={() => handleQuickAction('sqrt')}
          className="py-3.5 text-lg font-semibold text-indigo-400 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/50 rounded-2xl transition-all active:scale-95"
        >
          √
        </button>
        <button
          onClick={() => handleQuickAction('sqr')}
          className="py-3.5 text-sm font-semibold text-indigo-400 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/50 rounded-2xl transition-all active:scale-95"
        >
          x²
        </button>
        <button
          onClick={() => handleQuickAction('percent')}
          className="py-3.5 text-lg font-semibold text-indigo-400 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/50 rounded-2xl transition-all active:scale-95"
        >
          %
        </button>
        <button
          onClick={() => handleKeyPress('÷')}
          className="py-3.5 text-xl font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-2xl transition-all active:scale-95"
        >
          ÷
        </button>

        {/* Row 3 */}
        {[7, 8, 9].map((num) => (
          <button
            key={num}
            onClick={() => handleKeyPress(num.toString())}
            className="py-3.5 text-xl font-semibold text-slate-100 bg-slate-900/40 hover:bg-slate-800/40 border border-slate-800/30 rounded-2xl transition-all active:scale-95"
          >
            {num}
          </button>
        ))}
        <button
          onClick={() => handleKeyPress('×')}
          className="py-3.5 text-xl font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-2xl transition-all active:scale-95"
        >
          ×
        </button>

        {/* Row 4 */}
        {[4, 5, 6].map((num) => (
          <button
            key={num}
            onClick={() => handleKeyPress(num.toString())}
            className="py-3.5 text-xl font-semibold text-slate-100 bg-slate-900/40 hover:bg-slate-800/40 border border-slate-800/30 rounded-2xl transition-all active:scale-95"
          >
            {num}
          </button>
        ))}
        <button
          onClick={() => handleKeyPress('-')}
          className="py-3.5 text-xl font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-2xl transition-all active:scale-95"
        >
          -
        </button>

        {/* Row 5 */}
        {[1, 2, 3].map((num) => (
          <button
            key={num}
            onClick={() => handleKeyPress(num.toString())}
            className="py-3.5 text-xl font-semibold text-slate-100 bg-slate-900/40 hover:bg-slate-800/40 border border-slate-800/30 rounded-2xl transition-all active:scale-95"
          >
            {num}
          </button>
        ))}
        <button
          onClick={() => handleKeyPress('+')}
          className="py-3.5 text-xl font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-2xl transition-all active:scale-95"
        >
          +
        </button>

        {/* Row 6 */}
        <button
          onClick={handleToggleSign}
          className="py-3.5 text-lg font-semibold text-slate-300 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/50 rounded-2xl transition-all active:scale-95"
        >
          +/-
        </button>
        <button
          onClick={() => handleKeyPress('0')}
          className="py-3.5 text-xl font-semibold text-slate-100 bg-slate-900/40 hover:bg-slate-800/40 border border-slate-800/30 rounded-2xl transition-all active:scale-95"
        >
          0
        </button>
        <button
          onClick={() => handleKeyPress('.')}
          className="py-3.5 text-xl font-semibold text-slate-100 bg-slate-900/40 hover:bg-slate-800/40 border border-slate-800/30 rounded-2xl transition-all active:scale-95"
        >
          .
        </button>
        <button
          onClick={handleCalculate}
          className="py-3.5 text-2xl font-bold text-white bg-indigo-600 hover:bg-indigo-500 border border-indigo-500/30 rounded-2xl transition-all active:scale-95 shadow-lg shadow-indigo-600/30"
        >
          =
        </button>
      </div>

      <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
        <HelpCircle className="w-3.5 h-3.5" />
        <span>Keyboard input is active! You can type numbers and operators.</span>
      </div>
    </div>
  );
};
