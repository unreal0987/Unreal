import React from 'react';
import { Trash2, Copy, CornerDownLeft, Clock } from 'lucide-react';
import { playSound } from '../utils/audio';
import { translations, Language } from '../utils/translations';

export interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: string;
  type: 'standard' | 'scientific';
}

interface HistorySidebarProps {
  history: HistoryItem[];
  onClear: () => void;
  onSelect: (item: HistoryItem) => void;
  lang: Language;
  soundEnabled: boolean;
}

export const HistorySidebar: React.FC<HistorySidebarProps> = ({
  history,
  onClear,
  onSelect,
  lang,
  soundEnabled,
}) => {
  const t = translations[lang];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    if (soundEnabled) playSound('success');
    alert(t.copySuccess);
  };

  const handleSelect = (item: HistoryItem) => {
    if (soundEnabled) playSound('click');
    onSelect(item);
  };

  const handleClear = () => {
    if (soundEnabled) playSound('clear');
    onClear();
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/40 backdrop-blur-md rounded-2xl border border-slate-700/50 p-4 shadow-xl text-slate-100">
      <div className="flex items-center justify-between mb-4 border-b border-slate-700/50 pb-3">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <Clock className="w-5 h-5 text-indigo-400" />
          {t.history}
        </h3>
        {history.length > 0 && (
          <button
            onClick={handleClear}
            className="text-slate-400 hover:text-red-400 transition-colors p-1.5 rounded-lg hover:bg-slate-800/60"
            title={t.clearHistory}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 max-h-[350px] md:max-h-[500px] pr-1 custom-scrollbar">
        {history.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm">
            {t.noHistory}
          </div>
        ) : (
          history.map((item) => (
            <div
              key={item.id}
              className="group relative p-3 rounded-xl bg-slate-800/40 border border-slate-700/30 hover:border-indigo-500/50 transition-all hover:bg-slate-800/70"
            >
              <div className="text-right text-xs text-slate-500 mb-1">
                {new Date(item.timestamp).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </div>
              <div className="text-slate-300 text-sm font-mono break-all text-right mb-1">
                {item.expression}
              </div>
              <div className="text-indigo-300 font-mono font-semibold text-right break-all">
                = {item.result}
              </div>

              <div className="absolute left-2 bottom-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                <button
                  onClick={() => handleSelect(item)}
                  className="p-1 bg-indigo-600/80 hover:bg-indigo-600 text-white rounded-md transition-colors"
                  title="Load into calculator"
                >
                  <CornerDownLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleCopy(item.result)}
                  className="p-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-md transition-colors"
                  title="Copy result"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
