import React, { useState, useMemo } from 'react';
import { Calendar, Gift, Hourglass, HelpCircle } from 'lucide-react';
import { playSound } from '../utils/audio';
import { translations, Language } from '../utils/translations';

interface AgeTabProps {
  lang: Language;
  soundEnabled: boolean;
}

export const AgeTab: React.FC<AgeTabProps> = ({ lang, soundEnabled }) => {
  const t = translations[lang];

  // State: DOB and Target Date (default to today)
  const [dobString, setDobString] = useState<string>('2000-01-01');
  const [targetString, setTargetString] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const ageData = useMemo(() => {
    const dob = new Date(dobString);
    const target = new Date(targetString);

    // If invalid dates or DOB is in the future relative to target
    if (isNaN(dob.getTime()) || isNaN(target.getTime()) || dob > target) {
      return {
        isValid: false,
        years: 0,
        months: 0,
        days: 0,
        totalDays: 0,
        totalHours: 0,
        nextBirthdayMonths: 0,
        nextBirthdayDays: 0,
        isBirthdayToday: false,
      };
    }

    // 1. Calculate Exact Age (Years, Months, Days)
    let years = target.getFullYear() - dob.getFullYear();
    let months = target.getMonth() - dob.getMonth();
    let days = target.getDate() - dob.getDate();

    if (days < 0) {
      // Get days in the previous month of target
      const prevMonth = new Date(target.getFullYear(), target.getMonth(), 0);
      days += prevMonth.getDate();
      months--;
    }

    if (months < 0) {
      months += 12;
      years--;
    }

    // 2. Calculate Total Statistics
    const diffTime = target.getTime() - dob.getTime();
    const totalDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const totalHours = totalDays * 24;

    // 3. Calculate Next Birthday Countdown
    // Next birthday year is either target's year or target's year + 1
    const birthMonth = dob.getMonth();
    const birthDate = dob.getDate();

    let nextBirthdayYear = target.getFullYear();
    let nextBirthday = new Date(nextBirthdayYear, birthMonth, birthDate);

    // If birthday has already passed this year, it's next year
    if (nextBirthday < target) {
      nextBirthdayYear++;
      nextBirthday = new Date(nextBirthdayYear, birthMonth, birthDate);
    }

    // Is birthday today?
    const isBirthdayToday =
      target.getDate() === birthDate && target.getMonth() === birthMonth;

    // Difference between target and next birthday
    // To calculate months and days until next birthday:
    let nextBirthdayMonths = nextBirthday.getMonth() - target.getMonth();
    let nextBirthdayDays = nextBirthday.getDate() - target.getDate();

    if (nextBirthdayDays < 0) {
      const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
      nextBirthdayDays += prevMonth.getDate();
      nextBirthdayMonths--;
    }

    if (nextBirthdayMonths < 0) {
      nextBirthdayMonths += 12;
    }

    return {
      isValid: true,
      years,
      months,
      days,
      totalDays,
      totalHours,
      nextBirthdayMonths,
      nextBirthdayDays,
      isBirthdayToday,
    };
  }, [dobString, targetString]);

  const handleDateChange = (
    value: string,
    setter: React.Dispatch<React.SetStateAction<string>>
  ) => {
    if (soundEnabled) playSound('click');
    setter(value);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-950/80 backdrop-blur-xl rounded-3xl border border-slate-800 p-6 shadow-2xl">
      <h2 className="text-slate-100 font-bold text-lg mb-1 flex items-center gap-2">
        <Calendar className="w-5 h-5 text-indigo-400" />
        {t.tabAge}
      </h2>
      <p className="text-slate-400 text-xs mb-6">{t.ageDesc}</p>

      {/* Date Selectors */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="space-y-1.5">
          <label className="text-slate-400 text-xs font-medium uppercase tracking-wider">
            {t.birthDate}
          </label>
          <div className="relative">
            <input
              type="date"
              value={dobString}
              onChange={(e) => handleDateChange(e.target.value, setDobString)}
              className="w-full px-3 py-2.5 bg-slate-900 border border-slate-800 text-slate-100 rounded-xl font-mono text-sm focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-slate-400 text-xs font-medium uppercase tracking-wider">
            {t.compareDate}
          </label>
          <div className="relative">
            <input
              type="date"
              value={targetString}
              onChange={(e) => handleDateChange(e.target.value, setTargetString)}
              className="w-full px-3 py-2.5 bg-slate-900 border border-slate-800 text-slate-100 rounded-xl font-mono text-sm focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Validation Warning */}
      {!ageData.isValid && (
        <div className="bg-red-500/10 border border-red-500/25 rounded-2xl p-4 text-center text-red-400 text-sm font-medium">
          {lang === 'en'
            ? '⚠️ Please enter a valid date of birth that is earlier than or equal to the target date.'
            : '⚠️ कृपया सही जन्म तिथि चुनें जो गणना की तारीख से पहले या उसके बराबर हो।'}
        </div>
      )}

      {/* Main Results */}
      {ageData.isValid && (
        <div className="space-y-6">
          {/* Birthday Celebration Banner! */}
          {ageData.isBirthdayToday && (
            <div className="relative overflow-hidden bg-gradient-to-r from-pink-600/30 via-purple-600/30 to-indigo-600/30 border border-pink-500/30 rounded-2xl p-4 text-center shadow-lg animate-bounce duration-1000">
              <div className="absolute inset-0 flex justify-around items-center pointer-events-none opacity-40 select-none text-xl">
                <span>🎈</span>
                <span>🎉</span>
                <span>🎂</span>
                <span>✨</span>
                <span>🎁</span>
                <span>🎈</span>
              </div>
              <Gift className="w-8 h-8 text-pink-400 mx-auto mb-1 animate-wiggle" />
              <h3 className="text-base font-bold text-pink-300 tracking-wide">
                {t.happyBirthday}
              </h3>
            </div>
          )}

          {/* Age Grid */}
          <div className="grid grid-cols-3 gap-3">
            {/* Years */}
            <div className="bg-slate-900/60 border border-slate-850 rounded-2xl p-4 text-center shadow-sm">
              <div className="text-3xl md:text-4xl font-black text-indigo-400 font-mono tracking-tight">
                {ageData.years}
              </div>
              <div className="text-xs text-slate-400 font-medium mt-1 uppercase tracking-wider">
                {t.years}
              </div>
            </div>

            {/* Months */}
            <div className="bg-slate-900/60 border border-slate-850 rounded-2xl p-4 text-center shadow-sm">
              <div className="text-3xl md:text-4xl font-black text-amber-500 font-mono tracking-tight">
                {ageData.months}
              </div>
              <div className="text-xs text-slate-400 font-medium mt-1 uppercase tracking-wider">
                {t.months}
              </div>
            </div>

            {/* Days */}
            <div className="bg-slate-900/60 border border-slate-850 rounded-2xl p-4 text-center shadow-sm">
              <div className="text-3xl md:text-4xl font-black text-emerald-400 font-mono tracking-tight">
                {ageData.days}
              </div>
              <div className="text-xs text-slate-400 font-medium mt-1 uppercase tracking-wider">
                {t.days}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Lived Stats */}
            <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <Hourglass className="w-4 h-4 text-indigo-400" />
                {t.totalLived}
              </h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">{t.totalDays}</span>
                  <span className="font-bold text-slate-200 font-mono bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    {ageData.totalDays.toLocaleString()} Days
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">{t.totalHours}</span>
                  <span className="font-bold text-slate-200 font-mono bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    {ageData.totalHours.toLocaleString()} Hours
                  </span>
                </div>
              </div>
            </div>

            {/* Next Birthday Countdown */}
            {!ageData.isBirthdayToday && (
              <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 flex flex-col justify-between">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Gift className="w-4 h-4 text-pink-400" />
                  {t.nextBirthday}
                </h4>
                <div className="my-auto py-2">
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {t.birthdayIn}{' '}
                    <strong className="text-pink-400 font-mono font-bold">
                      {ageData.nextBirthdayMonths}
                    </strong>{' '}
                    {t.monthsAnd}{' '}
                    <strong className="text-pink-400 font-mono font-bold">
                      {ageData.nextBirthdayDays}
                    </strong>{' '}
                    {t.daysLeft}
                  </p>
                </div>

                {/* Progress bar to next birthday (approximate) */}
                <div className="w-full bg-slate-850 h-2 rounded-full overflow-hidden">
                  <div
                    style={{
                      width: `${((12 - ageData.nextBirthdayMonths) / 12) * 100}%`,
                    }}
                    className="bg-gradient-to-r from-pink-500 to-indigo-500 h-full rounded-full transition-all duration-500"
                  ></div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="mt-5 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
        <HelpCircle className="w-3.5 h-3.5" />
        <span>Leap years and varying month lengths are fully accounted for in calculations.</span>
      </div>
    </div>
  );
};
