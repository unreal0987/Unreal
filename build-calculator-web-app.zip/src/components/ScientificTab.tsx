import React, { useState, useEffect, useRef } from 'react';
import { Delete, HelpCircle } from 'lucide-react';
import { playSound } from '../utils/audio';
import { evaluateExpression, AngleMode } from '../utils/mathParser';
import { translations, Language } from '../utils/translations';
import { HistoryItem } from './HistorySidebar';

interface ScientificTabProps {
  lang: Language;
  soundEnabled: boolean;
  onAddHistory: (expression: string, result: string, type: 'standard' | 'scientific') => void;
  activeHistoryItem: HistoryItem | null;
}

export const ScientificTab: React.FC<ScientificTabProps> = ({
  lang,
  soundEnabled,
  onAddHistory,
  activeHistoryItem,
}) => {
  const t = translations[lang];
  const [expression, setExpression] = useState<string>('');
  const [result, setResult] = useState<string>('0');
  const [angleMode, setAngleMode] = useState<AngleMode>('deg');
  const [isCalculated, setIsCalculated] = useState<boolean>(false);
  const displayEndRef = useRef<HTMLDivElement>(null);

  // Load from history if selected
  useEffect(() => {
    if (activeHistoryItem && activeHistoryItem.type === 'scientific') {
      setExpression(activeHistoryItem.expression);
      setResult(activeHistoryItem.result);
      setIsCalculated(true);
    }
  }, [activeHistoryItem]);

  // Scroll to end of expression
  useEffect(() => {
    if (displayEndRef.current) {
      displayEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [expression]);

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }

      const key = e.key;
      if (/[0-9]/.test(key)) {
        handleKeyPress(key);
      } else if (key === '.') {
        handleKeyPress('.');
      } else if (key === '+') {
        handleKeyPress('+');
      } else if (key === '-') {
        handleKeyPress('-');
      } else if (key === '*') {
        handleKeyPress('×');
      } else if (key === '/') {
        handleKeyPress('÷');
      } else if (key === '^') {
        handleKeyPress('^');
      } else if (key === '!') {
        handleKeyPress('!');
      } else if (key === '(') {
        handleKeyPress('(');
      } else if (key === ')') {
        handleKeyPress(')');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleCalculate();
      } else if (key === 'Backspace') {
        handleBackspace();
      } else if (key === 'Escape') {
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [expression, isCalculated, angleMode]);

  const handleKeyPress = (char: string) => {
    if (soundEnabled) playSound('click');

    if (isCalculated) {
      if (['+', '-', '×', '÷', '^', '%'].includes(char)) {
        setExpression(result + ' ' + char + ' ');
      } else {
        setExpression(char);
      }
      setIsCalculated(false);
    } else {
      if (['+', '-', '×', '÷'].includes(char)) {
        setExpression((prev) => prev + ' ' + char + ' ');
      } else {
        setExpression((prev) => prev + char);
      }
    }
  };

  const handleFuncPress = (funcName: string) => {
    if (soundEnabled) playSound('click');
    if (isCalculated) {
      setExpression(funcName + '(');
      setIsCalculated(false);
    } else {
      setExpression((prev) => prev + funcName + '(');
    }
  };

  const handleClear = () => {
    if (soundEnabled) playSound('clear');
    setExpression('');
    setResult('0');
    setIsCalculated(false);
  };

  const handleBackspace = () => {
    if (soundEnabled) playSound('click');
    if (isCalculated) {
      setExpression('');
      setIsCalculated(false);
      return;
    }

    setExpression((prev) => {
      // Check if we are deleting a function like "sin(", "cos(", "tan(", "log(", "ln(", "√("
      if (prev.endsWith('sin(') || prev.endsWith('cos(') || prev.endsWith('tan(') || prev.endsWith('log(')) {
        return prev.slice(0, -4);
      }
      if (prev.endsWith('ln(') || prev.endsWith('√(')) {
        return prev.slice(0, -3);
      }
      if (prev.endsWith(' ')) {
        return prev.slice(0, -3); // Operator deletion
      }
      return prev.slice(0, -1);
    });
  };

  const handleCalculate = () => {
    if (!expression) return;
    try {
      const computed = evaluateExpression(expression, angleMode);
      let formattedResult = computed.toString();
      
      if (computed % 1 !== 0) {
        formattedResult = Number(computed.toFixed(10)).toString();
      }

      if (soundEnabled) playSound('success');
      setResult(formattedResult);
      onAddHistory(expression, formattedResult, 'scientific');
      setIsCalculated(true);
    } catch (err) {
      if (soundEnabled) playSound('error');
      setResult('Math Error');
      setIsCalculated(true);
    }
  };

  const toggleAngleMode = () => {
    if (soundEnabled) playSound('click');
    setAngleMode((prev) => (prev === 'deg' ? 'rad' : 'deg'));
  };

  const handleToggleSign = () => {
    if (soundEnabled) playSound('click');
    if (isCalculated) {
      const val = parseFloat(result);
      setResult((-val).toString());
      setExpression((-val).toString());
      setIsCalculated(false);
      return;
    }
    if (expression.startsWith('-(') && expression.endsWith(')')) {
      setExpression(expression.slice(2, -1));
    } else {
      setExpression(`-(${expression})`);
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-slate-950/80 backdrop-blur-xl rounded-3xl border border-slate-800 p-5 shadow-2xl">
      {/* Header Info */}
      <div className="text-slate-400 text-xs mb-3 flex items-center justify-between font-medium">
        <span>{t.scientificDesc}</span>
        <div className="flex items-center gap-2">
          <button
            onClick={toggleAngleMode}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border ${
              angleMode === 'deg'
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/25'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            DEG
          </button>
          <button
            onClick={toggleAngleMode}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border ${
              angleMode === 'rad'
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/25'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            RAD
          </button>
        </div>
      </div>

      {/* Display Screen */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800/80 mb-4 shadow-inner text-right flex flex-col justify-between min-h-[110px] overflow-hidden">
        <div className="text-slate-500 text-sm font-mono overflow-x-auto whitespace-nowrap pb-1 scrollbar-none flex justify-end">
          <div className="flex items-center gap-1">
            <span className="text-[10px] uppercase font-bold text-indigo-500/80 bg-indigo-500/10 px-1.5 py-0.25 rounded border border-indigo-500/20 mr-1">
              {angleMode}
            </span>
            {expression || '0'}
            <div ref={displayEndRef} />
          </div>
        </div>
        <div className="text-slate-100 text-3xl font-bold font-mono tracking-tight select-all break-all overflow-x-auto max-h-[80px] custom-scrollbar">
          {result}
        </div>
      </div>

      {/* Button Layout - 5 Columns */}
      <div className="grid grid-cols-5 gap-2">
        {/* Row 1 */}
        <button
          onClick={() => handleFuncPress('sin')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          sin
        </button>
        <button
          onClick={() => handleFuncPress('cos')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          cos
        </button>
        <button
          onClick={() => handleFuncPress('tan')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          tan
        </button>
        <button
          onClick={handleClear}
          className="py-3 text-sm font-bold text-red-400 bg-red-500/10 hover:bg-red-500/20 border border-red-500/25 rounded-xl transition-all active:scale-95"
        >
          C
        </button>
        <button
          onClick={handleBackspace}
          className="py-3 text-sm font-bold text-slate-400 bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800/40 rounded-xl transition-all active:scale-95 flex items-center justify-center"
        >
          <Delete className="w-4.5 h-4.5" />
        </button>

        {/* Row 2 */}
        <button
          onClick={() => handleFuncPress('log')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          log
        </button>
        <button
          onClick={() => handleFuncPress('ln')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          ln
        </button>
        <button
          onClick={() => handleKeyPress('^')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          xʸ
        </button>
        <button
          onClick={() => handleKeyPress('(')}
          className="py-3 text-sm font-bold text-slate-300 bg-slate-900/50 hover:bg-slate-800/50 border border-slate-800/30 rounded-xl transition-all active:scale-95"
        >
          (
        </button>
        <button
          onClick={() => handleKeyPress(')')}
          className="py-3 text-sm font-bold text-slate-300 bg-slate-900/50 hover:bg-slate-800/50 border border-slate-800/30 rounded-xl transition-all active:scale-95"
        >
          )
        </button>

        {/* Row 3 */}
        <button
          onClick={() => handleFuncPress('√')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          √x
        </button>
        <button
          onClick={() => handleKeyPress('!')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          x!
        </button>
        <button
          onClick={() => handleKeyPress('π')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          π
        </button>
        <button
          onClick={() => handleKeyPress('e')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          e
        </button>
        <button
          onClick={() => handleKeyPress('÷')}
          className="py-3 text-base font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-xl transition-all active:scale-95"
        >
          ÷
        </button>

        {/* Row 4 */}
        <button
          onClick={() => handleKeyPress('7')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          7
        </button>
        <button
          onClick={() => handleKeyPress('8')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          8
        </button>
        <button
          onClick={() => handleKeyPress('9')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          9
        </button>
        <button
          onClick={() => handleKeyPress('%')}
          className="py-3 text-sm font-bold text-indigo-300 bg-slate-900/60 hover:bg-indigo-800/40 border border-slate-800/40 rounded-xl transition-all active:scale-95"
        >
          %
        </button>
        <button
          onClick={() => handleKeyPress('×')}
          className="py-3 text-base font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-xl transition-all active:scale-95"
        >
          ×
        </button>

        {/* Row 5 */}
        <button
          onClick={() => handleKeyPress('4')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          4
        </button>
        <button
          onClick={() => handleKeyPress('5')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          5
        </button>
        <button
          onClick={() => handleKeyPress('6')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          6
        </button>
        <button
          onClick={handleToggleSign}
          className="py-3 text-xs font-bold text-slate-300 bg-slate-900/50 hover:bg-slate-800/50 border border-slate-800/30 rounded-xl transition-all active:scale-95"
        >
          +/-
        </button>
        <button
          onClick={() => handleKeyPress('-')}
          className="py-3 text-base font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-xl transition-all active:scale-95"
        >
          -
        </button>

        {/* Row 6 */}
        <button
          onClick={() => handleKeyPress('1')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          1
        </button>
        <button
          onClick={() => handleKeyPress('2')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          2
        </button>
        <button
          onClick={() => handleKeyPress('3')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          3
        </button>
        <button
          onClick={() => handleKeyPress('0')}
          className="py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
        >
          0
        </button>
        <button
          onClick={() => handleKeyPress('+')}
          className="py-3 text-base font-bold text-amber-500 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-xl transition-all active:scale-95"
        >
          +
        </button>

        {/* Row 7 */}
        <div className="col-span-4 grid grid-cols-4 gap-2">
          <div className="col-span-3">
            <button
              onClick={() => handleKeyPress('.')}
              className="w-full py-3 text-lg font-semibold text-slate-100 bg-slate-900/30 hover:bg-slate-800/30 border border-slate-850 rounded-xl transition-all active:scale-95"
            >
              .
            </button>
          </div>
          <div className="col-span-1">
            {/* Filler for layout if we want, or just empty space */}
          </div>
        </div>
        <button
          onClick={handleCalculate}
          className="py-3 text-xl font-bold text-white bg-indigo-600 hover:bg-indigo-500 border border-indigo-500/30 rounded-xl transition-all active:scale-95 shadow-lg shadow-indigo-600/30"
        >
          =
        </button>
      </div>

      <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
        <HelpCircle className="w-3.5 h-3.5" />
        <span>Keyboard active! Functions like sin(x) can be entered via buttons.</span>
      </div>
    </div>
  );
};
