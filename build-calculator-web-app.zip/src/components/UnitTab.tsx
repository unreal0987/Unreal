import React, { useState, useEffect, useMemo } from 'react';
import { RefreshCw, Copy, HelpCircle, ArrowLeftRight } from 'lucide-react';
import { playSound } from '../utils/audio';
import { translations, Language } from '../utils/translations';

interface UnitTabProps {
  lang: Language;
  soundEnabled: boolean;
}

type Category = 'length' | 'weight' | 'temperature' | 'area';

interface UnitOption {
  value: string;
  label: string;
}

export const UnitTab: React.FC<UnitTabProps> = ({ lang, soundEnabled }) => {
  const t = translations[lang];

  // Selected Category
  const [category, setCategory] = useState<Category>('length');
  const [inputValue, setInputValue] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState<string>('m');
  const [toUnit, setToUnit] = useState<string>('cm');

  // Define Unit Options per Category
  const unitOptions = useMemo<Record<Category, UnitOption[]>>(() => ({
    length: [
      { value: 'm', label: lang === 'en' ? 'Meter (m)' : 'मीटर (m)' },
      { value: 'km', label: lang === 'en' ? 'Kilometer (km)' : 'किलोमीटर (km)' },
      { value: 'cm', label: lang === 'en' ? 'Centimeter (cm)' : 'सेंटीमीटर (cm)' },
      { value: 'mm', label: lang === 'en' ? 'Millimeter (mm)' : 'मिलीमीटर (mm)' },
      { value: 'mi', label: lang === 'en' ? 'Mile (mi)' : 'मील (mi)' },
      { value: 'yd', label: lang === 'en' ? 'Yard (yd)' : 'गज (yd)' },
      { value: 'ft', label: lang === 'en' ? 'Foot (ft)' : 'फ़ीट (ft)' },
      { value: 'in', label: lang === 'en' ? 'Inch (in)' : 'इंच (in)' },
    ],
    weight: [
      { value: 'kg', label: lang === 'en' ? 'Kilogram (kg)' : 'किलोग्राम (kg)' },
      { value: 'g', label: lang === 'en' ? 'Gram (g)' : 'ग्राम (g)' },
      { value: 'lb', label: lang === 'en' ? 'Pound (lb)' : 'पाउंड (lb)' },
      { value: 'oz', label: lang === 'en' ? 'Ounce (oz)' : 'औंस (oz)' },
      { value: 'st', label: lang === 'en' ? 'Stone (st)' : 'स्टोन (st)' },
    ],
    temperature: [
      { value: 'C', label: 'Celsius (°C)' },
      { value: 'F', label: 'Fahrenheit (°F)' },
      { value: 'K', label: 'Kelvin (K)' },
    ],
    area: [
      { value: 'm2', label: lang === 'en' ? 'Square Meter (m²)' : 'वर्ग मीटर (m²)' },
      { value: 'km2', label: lang === 'en' ? 'Square Kilometer (km²)' : 'वर्ग किलोमीटर (km²)' },
      { value: 'mi2', label: lang === 'en' ? 'Square Mile (mi²)' : 'वर्ग मील (mi²)' },
      { value: 'acre', label: lang === 'en' ? 'Acre' : 'एकड़' },
      { value: 'hectare', label: lang === 'en' ? 'Hectare' : 'हेक्टेयर' },
    ],
  }), [lang]);

  // Set default units when category changes
  useEffect(() => {
    if (category === 'length') {
      setFromUnit('m');
      setToUnit('cm');
    } else if (category === 'weight') {
      setFromUnit('kg');
      setToUnit('g');
    } else if (category === 'temperature') {
      setFromUnit('C');
      setToUnit('F');
    } else if (category === 'area') {
      setFromUnit('m2');
      setToUnit('acre');
    }
  }, [category]);

  // Conversion rates relative to base unit
  // Length base: meter (m)
  const lengthRates: Record<string, number> = {
    m: 1,
    km: 1000,
    cm: 0.01,
    mm: 0.001,
    mi: 1609.344,
    yd: 0.9144,
    ft: 0.3048,
    in: 0.0254,
  };

  // Weight base: kilogram (kg)
  const weightRates: Record<string, number> = {
    kg: 1,
    g: 0.001,
    lb: 0.45359237,
    oz: 0.028349523,
    st: 6.35029318,
  };

  // Area base: square meter (m2)
  const areaRates: Record<string, number> = {
    m2: 1,
    km2: 1000000,
    mi2: 2589988.11,
    acre: 4046.8564,
    hectare: 10000,
  };

  // Core conversion calculation
  const convertedValue = useMemo<string>(() => {
    const num = parseFloat(inputValue);
    if (isNaN(num)) return '0';

    if (fromUnit === toUnit) return num.toString();

    if (category === 'length') {
      const inMeters = num * lengthRates[fromUnit];
      const target = inMeters / lengthRates[toUnit];
      return Number(target.toFixed(8)).toString();
    }

    if (category === 'weight') {
      const inKg = num * weightRates[fromUnit];
      const target = inKg / weightRates[toUnit];
      return Number(target.toFixed(8)).toString();
    }

    if (category === 'area') {
      const inM2 = num * areaRates[fromUnit];
      const target = inM2 / areaRates[toUnit];
      return Number(target.toFixed(8)).toString();
    }

    if (category === 'temperature') {
      // Custom temperature formulas
      let celsius = 0;

      // Convert to Celsius first
      if (fromUnit === 'C') {
        celsius = num;
      } else if (fromUnit === 'F') {
        celsius = (num - 32) / 1.8;
      } else if (fromUnit === 'K') {
        celsius = num - 273.15;
      }

      // Convert from Celsius to target
      let target = 0;
      if (toUnit === 'C') {
        target = celsius;
      } else if (toUnit === 'F') {
        target = celsius * 1.8 + 32;
      } else if (toUnit === 'K') {
        target = celsius + 273.15;
      }

      return Number(target.toFixed(4)).toString();
    }

    return '0';
  }, [category, fromUnit, toUnit, inputValue]);

  // Actions
  const handleSwap = () => {
    if (soundEnabled) playSound('click');
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
  };

  const handleCopy = () => {
    if (soundEnabled) playSound('success');
    navigator.clipboard.writeText(convertedValue);
    alert(t.copySuccess);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-950/80 backdrop-blur-xl rounded-3xl border border-slate-800 p-6 shadow-2xl">
      <h2 className="text-slate-100 font-bold text-lg mb-1 flex items-center gap-2">
        <RefreshCw className="w-5 h-5 text-indigo-400" />
        {t.tabUnit}
      </h2>
      <p className="text-slate-400 text-xs mb-6">{t.unitDesc}</p>

      {/* Category Buttons */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 mb-6">
        {(['length', 'weight', 'temperature', 'area'] as Category[]).map((cat) => {
          const isActive = category === cat;
          return (
            <button
              key={cat}
              onClick={() => {
                if (soundEnabled) playSound('click');
                setCategory(cat);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                isActive
                  ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/25'
                  : 'bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              {cat === 'length'
                ? t.length
                : cat === 'weight'
                ? t.weightUnit
                : cat === 'temperature'
                ? t.temperature
                : t.area}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-9 gap-4 items-center">
        {/* From Section */}
        <div className="md:col-span-4 space-y-2">
          <label className="text-slate-400 text-xs font-semibold uppercase tracking-wider">
            {t.fromUnit}
          </label>
          <select
            value={fromUnit}
            onChange={(e) => {
              if (soundEnabled) playSound('click');
              setFromUnit(e.target.value);
            }}
            className="w-full px-3 py-2 bg-slate-900 border border-slate-800 text-slate-100 rounded-xl text-sm focus:outline-none focus:border-indigo-500 font-medium"
          >
            {unitOptions[category].map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <div className="relative">
            <input
              type="number"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={t.inputValue}
              className="w-full px-3 py-2.5 bg-slate-900 border border-slate-800 text-slate-100 rounded-xl font-mono font-bold text-base focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Swap Button Column */}
        <div className="md:col-span-1 flex justify-center pt-5 md:pt-0">
          <button
            onClick={handleSwap}
            className="p-3 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-indigo-400 hover:text-indigo-300 rounded-full transition-all active:scale-90 hover:shadow-md"
            title="Swap Units"
          >
            <ArrowLeftRight className="w-5 h-5 rotate-90 md:rotate-0" />
          </button>
        </div>

        {/* To Section */}
        <div className="md:col-span-4 space-y-2">
          <label className="text-slate-400 text-xs font-semibold uppercase tracking-wider">
            {t.toUnit}
          </label>
          <select
            value={toUnit}
            onChange={(e) => {
              if (soundEnabled) playSound('click');
              setToUnit(e.target.value);
            }}
            className="w-full px-3 py-2 bg-slate-900 border border-slate-800 text-slate-100 rounded-xl text-sm focus:outline-none focus:border-indigo-500 font-medium"
          >
            {unitOptions[category].map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <div className="relative">
            <input
              type="text"
              readOnly
              value={convertedValue}
              className="w-full px-3 py-2.5 bg-slate-900 border border-slate-800 text-indigo-300 rounded-xl font-mono font-bold text-base select-all cursor-default focus:outline-none"
            />
            <button
              onClick={handleCopy}
              className="absolute right-2 top-1.5 p-1.5 bg-slate-850 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-lg transition-colors"
              title="Copy Result"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
        <HelpCircle className="w-3.5 h-3.5" />
        <span>Conversions are computed instantly. High precision floating-point is maintained.</span>
      </div>
    </div>
  );
};
